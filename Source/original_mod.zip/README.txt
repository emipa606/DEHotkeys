DEHotkeys v. 1.1

A Rimworld mod by DemonEinstein


Features:
	This mod makes the order hotkeys work when you are not in the order menu. The hotkeys are disabled
	whenever you are in another menu that involves hotkeys so that they do not interfere. The mod also
	adds two new hotkeys which did not previously have their own keys: J to harvest wood and Z to
	uninstall buildings.


uses Harmony v1.1.0 by pardeike


MIT License

Released August 10, 2018